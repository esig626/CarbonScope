# Agent A proposal: R1 COBRA-to-isotope atom-map crosswalk

Status: **PROPOSAL ONLY — HARD MAPPING GAPS FOUND**

This report is the Stage B Agent A deliverable. It does not freeze the
crosswalk. No mfapy module was imported or executed; no tracer, EMU graph,
forward calculation, MID, measurement draw, or inference object was created.

## Source separation and search result

The COBRA model and frozen Stage A2 artifacts were used only to identify
physical metabolites and reaction context. Atom transitions were copied from
the checked mapped sources. No mapping was derived from COBRA stoichiometry.
The direct E. coli authority is
`vendor/mfapy/sample/Example_2_Ecoli_model.txt`, corroborated by the Tutorial 1
copy. `Example_3_MCF7_model.txt` supplies direct glutamine/glutamate/aKG
identity-skeleton directions that are absent from Example 2. The checked
carbon-transition library at commit/tag `5a1c26b` / `v0.4.0-carbon-library`
was inspected as a normalized, tested secondary representation.

The older `codex/examples/ecoli_core` forward smoke fixture is **not** a valid
R1 authority. It gives TPI as `DHAP abc -> GAP cba`, contradicting Example 2
`ABC -> ABC`, and gives identity-order standalone CS/aconitase maps instead of
the authoritative net condensation `AB + CDEF -> FEDBAC`. Reusing that fixture
would silently change atom chemistry.

No internet source was queried. Legacy files under `references/` were
inspected and rejected as unverified/partial examples. The protected untracked
PDF was not opened or modified.

## Candidate metabolite crosswalk

The explicit proposal is in `agent_a_metabolite_crosswalk_proposal.csv`.
The biochemical identities used for the retained ancestry are unambiguous
when formulas, identifiers, carbon counts, and reaction context are combined.
Important non-one-to-one cases are explicit:

- COBRA acetyl-CoA has formula C23, but the isotope source authoritatively
  tracks only its two acetyl carbons. Succinyl-CoA is an omitted intermediate
  in the source aKG-to-succinate net mapping.
- `PGA` is the source's three-carbon lower-glycolysis endpoint, collapsing
  COBRA 13DPG/3PG/2PG steps. Neither 13DPG nor 2PG is name-matched or assigned
  an invented standalone map.
- `IsoCit` is the source's combined citrate/aconitase/isocitrate endpoint.
  COBRA citrate and cis-aconitate are not declared equivalent to isocitrate;
  they are suppressed only through an audited lump.
- 6-phosphogluconolactone, glyoxylate, and acetyl phosphate are suppressed
  physical intermediates for source-backed net maps, not guessed matches.
- Intracellular and extracellular pools remain distinct rows.

## Candidate reaction crosswalk

`agent_a_reaction_crosswalk_proposal.csv` preserves every direct source atom
string. The principal supported non-one-to-one projections are:

1. **Glucose PTS decomposition.** One physical `GLCpts` flux drives two
   source-backed mapping components: `SubsGlc -> G6P`, `ABCDEF -> ABCDEF`, and
   `PEP -> Pyr`, `ABC -> ABC`. Both receive exactly `v_GLCpts`; all 9 substrate
   and 9 product carbons are accounted for. A bare glucose-to-G6P map would be
   incomplete.
2. **Lower glycolysis.** `GAPD;PGK` uses source r10 only if
   `v_GAPD=-v_PGK`; `PGM;ENO` uses source r12 only if
   `-v_PGM=v_ENO`. The omitted pools are unbranched in the checked core.
3. **Citrate/isocitrate.** `CS;ACONTa;ACONTb` uses source r17 only if all
   three physical fluxes agree. The exact permuted map is retained.
4. **aKG to succinate.** `AKGDH;SUCOAS` uses source r19 only if
   `v_AKGDH=-v_SUCOAS`.
5. **Glyoxylate bypass.** `ICL;MALS` uses source r26 only if the two fluxes
   agree. This is the only checked map that accounts for both isocitrate and
   acetyl-CoA carbon fates without inventing a glyoxylate map.
6. **Oxidative PPP.** `G6PDH2r;PGL` uses source r27 only if the fluxes agree.
   The checked transition library explicitly lists individual G6PD/6PGL maps
   as unresolved, so they must not be expanded.
7. **Acetate overflow.** `PTAr;ACKr` uses source r49 only if
   `v_PTAr=-v_ACKr`; downstream acetate transport/export is turnover-only.

An initially tempting decomposition of `GLUSy` into one `Gln -> Glu` and one
`aKG -> Glu` component was rejected after a repository-wide direct-source
audit. Those two identity-skeleton maps exist for other enzymes, but no checked
source asserts their joint use for `GLUSy`. Combining them here would create a
new two-skeleton reaction map from stoichiometry and mechanistic knowledge.

The candidate reporter overlay is direct and nonphysical:

- Ala: Example 2 r58, `Pyr -> Ala`, `ABC -> ABC`;
- Asp: Example 2 r59, `Oxa -> Asp`, `ABCD -> ABCD`;
- Glu: Example 2 r61, `aKG -> Glu`, `ABCDE -> ABCDE`.

These mappings must never add COBRA reactions, alter bounds, or withdraw
physical precursor flux.

## Direction and symmetry findings

The already frozen Stage A2 per-class summary includes exact class FVA columns
and was read only as preliminary coverage evidence; Agent C must reproduce the
Stage B FVA. It indicates that direct source reverse maps are needed for PGI,
RPE, TKT1, TALA, TKT2, FUM, and MDH. Those directions are present explicitly
in Example 2. RPI is required only in the COBRA-reverse Ru5P-to-R5P direction,
also explicit. ICDHyr is positive in both class ranges, so its absent reverse
map is not currently required.

Succinate and fumarate retain the source `symmetry` declarations. The checked
transition library makes the corresponding orientations explicit as equal
0.5/0.5 branches and validates their weights. No arbitrary orientation should
replace them.

The one candidate based on formal inversion rather than an explicit reverse
source line is `GLNS` (`Glu -> Gln`). The checked library defines the exact
inverse of the direct `Gln -> Glu` identity map and its validator/test suite
checks complete carbon accounting, branch preservation, and double inversion.
Agent B must explicitly accept or reject this under the user's reverse-map
gate; it is not needed to justify either hard gap below.

## Hard stop 1: biomass produces retained aKG without an atom map

`BIOMASS_Ecoli_core_w_GAM` is not merely a turnover sink. Its frozen COBRA
stoichiometry includes:

```text
4.9414 glu__L_c + 0.2557 gln__L_c + ...
    -> 4.1182 akg_c + ...
```

Every frozen state has positive biomass. At the common viability floor,
`4.1182 * 0.5243529041810849 = 2.159390129998544` units of aKG production are
therefore unavoidable; the sampled libraries have even larger biomass fluxes.
aKG is a retained isotope-visible ancestry pool for the Glu reporter and for
TCA targets.

The checked isotope sources contain `Glu -> aKG` as a real carbon-skeleton
reaction and contain independent pseudo biomass drains, but **none attaches an
atom origin to the 4.1182 aKG product of this COBRA biomass pseudo-reaction**.
Pairing that product with a selected amount of consumed glutamate would be a
new biochemical decomposition inferred from stoichiometry. Treating the whole
biomass reaction as turnover-only would silently drop production into a
retained pool and fail the required projected aKG balance.

This is a potentially active mapped-production gap and triggers the user's
stop conditions.

## Hard stop 2: potentially active extracellular succinate return has no map

The class-summary exact FVA ranges are:

| Reaction | Theta 0 | Theta 1 |
|---|---:|---:|
| `SUCCt2_2` (`succ_e -> succ_c`) | `[0, 4.5763]` | `[0, 18.270]` |
| `SUCCt3` (`succ_c -> succ_e`) | `[0, 4.5763]` | `[0, 18.270]` |

The frozen ACHR libraries actually use both directions: `SUCCt2_2` ranges
`0.002105..0.861112` in Theta 0 and `0.018084..5.650403` in Theta 1. Thus this
is not only an unsampled-polytope concern. The pair can recycle extracellular
succinate while net exchange remains secretion-only.

Example 2 r53 provides only `Suc -> Succinateex` with atom map `nd`; it has no
explicit internal/external identity transition and no reverse direction.
`SUCCt3` can be turnover-only because it consumes a retained pool, but
`SUCCt2_2` produces the retained, explicitly requested succinate target from a
distinct extracellular pool. Calling that production irrelevant, silently
collapsing compartments, or manufacturing an identity map would violate the
Stage B rules.

This is a second independently sufficient mapping stop.

## Hard stop 3: GLUSy has no authoritative two-skeleton transition

The frozen core reaction is:

```text
akg_c + gln__L_c + h_c + nadph_c -> 2 glu__L_c + nadp_c
```

Class-restricted FVA permits forward `GLUSy` in both classes (`[0, 3.4322]`
in Theta 0 and `[0, 13.7022]` in Theta 1). More strongly, all 200 frozen ACHR
states use it: Theta 0 ranges `0.00123377..0.698961`, and Theta 1 ranges
`0.0154402..4.464701`. `GLUDy` can also run `Glu -> aKG` in Theta 1 (ten of
the 100 frozen states do so), so the Glu/Gln network is in aKG target ancestry
rather than an ignorable side system.

Repository-wide search found direct maps for `Gln -> Glu` and for
`aKG -> Glu` as separate physical reactions, but no explicit map for the
two-substrate/two-product `GLUSy` reaction. The required mapping is
biochemically plausible as two preserved five-carbon skeletons, but Stage B
does not authorize reconstructing it from reaction stoichiometry or general
mechanistic knowledge. It is therefore a third mapped-production gap.

## Proposal verdict

The repository supplies authoritative maps for PTS dual-carbon transfer,
glycolysis, PPP, the TCA sequence, glyoxylate bypass, anaplerosis, acetate
formation, PFL, several nitrogen-linked aKG reactions, and all three reporter
transitions. The seven requested target identities and carbon counts are
defined, but three active production mechanisms in their ancestry remain
unsupported.

Nevertheless, the projection cannot currently attain zero unexplained
production gaps for every frozen state. Agent A recommends **BLOCKED**, not a
partial or complete freeze, unless independent review finds already checked
authoritative mappings for `BIOMASS_Ecoli_core_w_GAM -> akg_c` production,
forward `SUCCt2_2` compartmental transfer, and `GLUSy`. No chemistry should be
invented to bypass any gap.
