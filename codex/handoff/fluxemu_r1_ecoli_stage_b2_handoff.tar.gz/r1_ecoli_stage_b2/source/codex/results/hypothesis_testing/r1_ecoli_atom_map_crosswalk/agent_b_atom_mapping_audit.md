# Agent B independent atom-mapping audit

## Verdict

**FAIL / Stage B blocking gaps found.** The checked repository gives strong,
carbon-complete coverage for the conventional central-carbon network, the PTS
decomposition, the seven reporter/target definitions, and the necessary
flux-equal central-pathway lumps. The prompt-permitted decomposition of
`GLUSy:forward` is supported by two explicit checked five-carbon skeleton maps
at the same physical COBRA flux. However, the repository does not provide
authoritative production maps for three class-relevant COBRA directions:

1. `SUCCt3:forward`, which produces the extracellular succinate precursor
   pool from intracellular succinate;
2. `SUCCt2_2:forward`, which returns that pool into the frozen intracellular
   succinate target; and
3. `BIOMASS_Ecoli_core_w_GAM:forward`, whose pseudo-reaction produces
   `4.1182 akg_c` per unit biomass.

The zero-unexplained-production-gap gate therefore cannot pass without adding
an external checked mapping source, changing the already frozen feasible set,
or inventing carbon ancestry. None of those actions is permitted in Stage B.

This audit was performed independently from Agent A's proposal. No Agent A
artifact was read.

## Firewall

Only text/YAML/SBML metadata, stable-COBRA class FVA, frozen flux tables, and
mapping-schema validation were inspected. No tracer object was instantiated;
no EMU graph was compiled; no isotope equation was solved; and no MID,
measurement draw, or inference result was generated. No mfapy model or forward
function was imported or called. The mfapy files were parsed as text only.

## Checked mapping sources

| Source | SHA-256 / role | Audit result |
|---|---|---|
| `vendor/mfapy/sample/Example_2_Ecoli_model.txt` | `b73814d98a7190bfd6aae8ccfc64ebff78032826cbac806ba943b64bacacf899` | Primary checked E. coli transition source |
| `vendor/mfapy/sample/Tutorial 1_13C-MFAEcoli_model.txt` | `e2a2f913ce0549c0e4b96e022dd6e95ed39c0324a5ddbb3a5d1db9db18ca388d` | Independent checked copy of the same 103 atom maps |
| `vendor/mfapy/sample/Example_3_MCF7_model.txt` | `d0c410f44877af1fabef63b191885cddb27f79c00d518a588b11820fe9646aa6` | Explicit paired TCA/GLUDy maps and reporter mappings |
| `vendor/mfapy/sample/Example_7_CancerCell_model.txt` | `11d970c86867fa03c2537684f7c395900b8c48ed288f66fa7a4e4af61545fa46` | Explicit paired glutaminase/GLUDH maps and full R5P/S7P/Suc/Mal target declarations |
| `codex/src/fluxemu/carbon_transitions/data/*.yaml` | 44 validated transitions / 35 metabolites | Curated normalized maps, numbering, provenance, reverse validation, and symmetry branches |
| `codex/examples/antoniewicz_tca/build_model.py` and `PAPER_TRANSCRIPTION.md` | frozen Table 5 transcription | Gold citrate/TCA maps and explicit 0.5/0.5 succinate/fumarate orientations |
| `codex/src/fluxemu/carbon_transitions/{schema,validator,normalize,registry}.py` and `codex/tests/test_carbon_transitions.py` | checked validation machinery | Exact inversion and double-inversion tests inspected; mapping-only validation passed |

The two required E. coli files have identical reaction IDs, atom-mapping
equations, and atom-label strings for all 103 reactions. Four stoichiometric
spellings of duplicated substrates differ (`{2.0}PEP` versus repeated `PEP`,
and similarly for amino-acid synthesis), but their atom-mapping fields are
identical. Their bounds and status values were not used.

For the 47 source rows relevant to central metabolism and the reporters
(`r1`-`r42`, `r49`, `r51`, `r58`, `r59`, and `r61`), every participant atom
string matches the declared carbon count, every input label has one fate, and
every output label has one origin.

No external source was queried. The protected untracked PDF was neither read
nor modified. The checked frozen Table 5 transcription was sufficient for the
audit statements that rely on that source.

## Directional and reverse-map audit

Class-restricted FVA was independently reproduced using the frozen Stage A2
constraints only. No new states were sampled. The conventional central reverse
directions are covered by explicit checked source rows:

- PGI: Example 2 `r2` / `r3`;
- RPI: `r29` / `r30`;
- RPE: `r31` / `r32`;
- TKT1: `r33` / `r34`;
- TAL: `r35` / `r36`;
- TKT2: `r37` / `r38`;
- fumarase: `r22` / `r23`;
- malate dehydrogenase: `r24` / `r25`; and
- glutamate dehydrogenase: Example 3 `r49_gludh` / `r50_gludh`.

Thus no casual text-string reversal is necessary for these directions. The
repository's generic exact inversion utility is also formally guarded:
`reverse_branches` exchanges explicit endpoints, the validator double-inverts,
and the focused regression asserts exact recovery. A mapping-only check
validated all 44 packaged entries and double-inversion of all 25 reversible
entries.

Other potentially active forward carbon-producing directions also have direct
checked records: PFK/FBP (`r4`/`r5`), FBA/TPI (`r6`-`r9`), pyruvate kinase and
PEP synthase (`r14`/`r15`), PDH (`r16`), PFL (`r51`), oxidative PPP
(`r27`/`r28`), PEP carboxylase/PEP carboxykinase (`r40`/`r41`), malic enzyme
(`r42`), succinate dehydrogenase/fumarate reductase (`r20`/`r21`), and
glutamine/glutamate interconversion (Example 7 `r47_gls`/`r48_gls`).

Succinate and fumarate require special treatment. Example 2 marks both pools
as symmetric at lines 178-179. The checked mfapy implementation assigns a
factor of `0.5` to symmetry-generated orientations, and the normalized library
stores explicit `0.5 / 0.5` branches. This applies to succinate/fumarate,
fumarase, and any glyoxylate or AKGDH lump that produces succinate. A single
arbitrarily oriented identity map is not acceptable.

## Glucose PTS audit

`GLCpts` is not equivalent to `SubsGlc -> G6P` alone. The exact acceptable
decomposition is:

- Example 2 `r1`: `SubsGlc[ABCDEF] -> G6P[ABCDEF]`; and
- Example 2 `r14`: `PEP[ABC] -> Pyr[ABC]`.

Both components receive exactly the same physical `GLCpts` flux. Together they
account for all nine input and all nine output carbons in the COBRA reaction.
This mandatory audit passes.

## Auditable flux-equal lumps

The following candidate lumps have direct checked maps and structural equality
because the omitted core intermediate has no other producer or consumer. The
largest equality residual over the frozen 200 ACHR states plus the LP and pFBA
representatives is shown below.

| Lump | Exact flux relation | Source map | Maximum residual |
|---|---|---|---:|
| citrate synthase + both aconitase halves | `CS = ACONTa = ACONTb` | Example 2 `r17`, AcCOA + Oxa -> IsoCit | `1.69e-14` |
| AKGDH + succinyl-CoA synthetase | `AKGDH = -SUCOAS` | `r19`, aKG -> Suc + CO2 | `7.46e-14` |
| isocitrate lyase + malate synthase | `ICL = MALS` | `r26`, IsoCit + AcCOA -> Mal + Suc | `6.22e-14` |
| G6PDH + lactonase | `G6PDH2r = PGL` | `r27`, G6P -> 6PG | `3.02e-14` |
| GAPD + reverse PGK | `GAPD = -PGK` | `r10`, GAP -> PGA | `4.77e-13` |
| reverse PGM + ENO | `ENO = -PGM` | `r12`, PGA -> PEP | `1.43e-14` |
| phosphotransacetylase + reverse acetate kinase | `PTAr = -ACKr` | `r49`, AcCOA -> Acetate | `1.07e-14` |

These are valid candidates only while the implementation asserts the exact
relations for every projected state. No equality was inferred merely from a
pathway name.

## Reporter and target audit

The reporter transitions are explicit in Example 2:

- `r58`: `Pyr[ABC] -> Ala[ABC]`;
- `r59`: `Oxa[ABCD] -> Asp[ABCD]`; and
- `r61`: `aKG[ABCDE] -> Glu[ABCDE]`.

They must remain zero-flux observational mappings rather than physical COBRA
reactions.

All seven frozen target position sets occur verbatim in checked source files:
Example 2 lines 203, 205, and 208 contain full Ala, Asp, and Glu; Example 7
lines 127, 129, 143, and 152 contain full Suc, Mal, R5P, and S7P.

## Allowed explicit reaction decomposition: `GLUSy:forward`

`GLUSy` is potentially active over both frozen polytopes:

- Theta 0: `[0, 3.4322]`;
- Theta 1: `[0, 13.702222]`.

It produces two intracellular glutamates from alpha-ketoglutarate and
glutamine. `GLUDy` ranges from `-2.8454207` to `10.977108` in Theta 1, so
glutamate can in turn produce retained alpha-ketoglutarate. The direction is
therefore inside target ancestry, not merely a sink. This is not merely an
intersection inferred from separate FVA extrema: 10 frozen Theta 1 ACHR states
have both `GLUSy > 0` and forward `GLUDy > 0`, and a direct Theta 1 feasibility
LP remains optimal when both lower bounds are set to `5`.

The checked sources do explicitly provide both carbon-skeleton components:

- Example 3 line 53 and Example 7 line 55: `Gln[ABCDE] -> Glu[ABCDE]`;
- Example 7 line 58 (also Example 3 line 55):
  `aKG[ABCDE] -> Glu[ABCDE]`.

The Stage B prompt expressly permits decomposing one physical reaction into
several mapping components when it transfers distinct carbon skeletons,
provided that every component is explicit and receives the same physical
COBRA flux. `GLUSy` meets that rule: the two checked identity components each
receive exactly `v_GLUSy`, collectively account for both five-carbon inputs
and both five-carbon glutamate products, and introduce no separately chosen
flux. The identical product-pool identity does not require choosing a novel
atom permutation. This is therefore a **conditional PASS**, contingent on the
projection encoding both components at the same physical flux and testing
that equality for every state.

## Blocking production-map gaps

### 1-2. `SUCCt3:forward` and `SUCCt2_2:forward`

`SUCCt2_2` directly produces the frozen intracellular succinate target:

- Theta 0: `[0, 4.5762667]`;
- Theta 1: `[0, 18.269629]`.

The checked E. coli source contains only `r53`, `Suc -> Succinateex`, and marks
both reaction mapping fields `nd`. Thus it supplies neither an explicit
`succ_c -> succ_e` atom transition for `SUCCt3` nor an explicit reverse import
map for `SUCCt2_2`.

`SUCCt3` cannot be classified as turnover-only once its product is recursively
traced. `succ_e` is consumed by potentially active `SUCCt2_2` into the frozen
target pool, so it is a retained target-ancestry precursor rather than an
unobserved terminal sink. Both transporters have the same potentially active
FVA ranges in each class.

The two directions also cannot be dismissed as harmless net secretion.
External steady state gives

`SUCCt3 - SUCCt2_2 = EX_succ_e`,

not equality of the two transport fluxes. `EX_succ_e` can reach `0.33484878`
in Theta 0 and `0.24061245` in Theta 1, while transporter cycling can be much
larger. Replacing both physical transporters by net export would silently drop
frozen physical flux and violates the specified equal-flux lumping rule.

### 3. `BIOMASS_Ecoli_core_w_GAM:forward`

The biomass pseudo-reaction is not wholly turnover-only. It produces
`4.1182 akg_c` per unit biomass and is bounded away from zero in both classes.
The corresponding alpha-ketoglutarate production is:

- Theta 0: `3.527003879` to `3.598983550`;
- Theta 1: `2.159390130` to `2.224586707`.

Omitting that production causes a material alpha-ketoglutarate pool-balance
gap. The checked isotope sources contain only separate biomass drains and no
explicit origin for the biomass pseudo-reaction's alpha-ketoglutarate product.
The presence elsewhere of an authoritative `Glu -> aKG` map does not prove
that the biomass product inherits those glutamate atoms. Assigning it from the
COBRA stoichiometry would violate the prohibition on deriving atom maps from
stoichiometry.

## Rejected conflicting prototype source

`codex/examples/ecoli_core/ATOM_MAPS.md` and its generated isotope SBML are not
acceptable R1 mapping authorities. They describe a previous 23-reaction
prototype and conflict with the checked source under the frozen source-map
numbering, including:

- FBA: prototype `DHAP[ABC]`, checked source `DHAP[CBA]`;
- TPI: prototype `ABC -> CBA`, checked source `ABC -> ABC`;
- PPC: a different CO2/OAA position assignment;
- CS/aconitase: prototype identity ordering, checked net source `FEDBAC`; and
- AKGDH: a different decarboxylated alpha-ketoglutarate position.

The normalized transition library agrees with the checked mfapy convention for
TPI (`ABC -> ABC`) and provides source provenance. The older prototype does
not. It must be rejected, not blended into the R1 catalogue.

## Required resolution

Stage B needs checked authoritative directional mappings for exactly these
unresolved production cases before it can pass:

1. `SUCCt3:forward`, the compartment-explicit `succ_c -> succ_e` production
   mapping with symmetry treatment;
2. `SUCCt2_2:forward`, the compartment-explicit `succ_e -> succ_c` production
   mapping with symmetry treatment; and
3. the `4.1182 akg_c` product component of
   `BIOMASS_Ecoli_core_w_GAM:forward`.

Until those are supplied, a complete deterministic projection with balanced
retained isotope pools cannot be frozen.
