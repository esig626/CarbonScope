# Agent D structural target-ancestry proposal

## Scope and verdict

This is an independent, structural, flux-only audit of exactly seven frozen
future targets: Ala full carbon, Asp full carbon, Glu full carbon, R5P full
carbon, S7P full carbon, succinate full carbon, and malate full carbon.  No
tracer object, EMU graph, isotope equation, MID, or inference calculation was
constructed or evaluated.

**Proposal verdict: BLOCKED.**  The checked repository mapping material is
not sufficient to close the target-ancestry union over the frozen Stage A2
classes.  Two precise mapped-production gaps are identified below:

1. `BIOMASS_Ecoli_core_w_GAM:forward` produces the retained `akg_c` pool, but
   the repository supplies no authoritative atom transition into that product.
2. `SUCCt2_2:forward` produces retained `succ_c` from `succ_e` in a physically
   active transport-recycling branch, but the repository supplies no explicit
   succinate compartment-transition map.

`GLUSy:forward` initially appears absent as a reaction-level record, but the
task's allowed multi-skeleton decomposition can cover it without inventing a
map: checked sources explicitly provide both `aKG ABCDE -> Glu ABCDE` and
`Gln ABCDE -> Glu ABCDE`.  Applying one instance of each component at the
same physical `v_GLUSy` accounts for the two glutamate product molecules and
all ten substrate carbons.  This is recorded as a source-backed decomposed
match subject to independent Agent B confirmation, not as a missing map.

These are STOP conditions under the Stage B specification.  They must not be
filled with identity maps inferred from reaction names or COBRA
stoichiometry.

## Sources inspected directly

- `vendor/mfapy/sample/Example_2_Ecoli_model.txt`
- `vendor/mfapy/sample/Tutorial 1_13C-MFAEcoli_model.txt`
- `vendor/mfapy/sample/Example_3_MCF7_model.txt`
- `vendor/mfapy/sample/Example_7_CancerCell_model.txt`
- `codex/src/fluxemu/carbon_transitions/data/metabolites.yaml`
- `codex/src/fluxemu/carbon_transitions/data/glycolysis.yaml`
- `codex/src/fluxemu/carbon_transitions/data/pentose_phosphate.yaml`
- `codex/src/fluxemu/carbon_transitions/data/tca.yaml`
- `codex/src/fluxemu/carbon_transitions/data/anaplerosis.yaml`
- `codex/src/fluxemu/carbon_transitions/data/glutaminolysis.yaml`
- `codex/src/fluxemu/carbon_transitions/data/malate_aspartate.yaml`
- `codex/src/fluxemu/carbon_transitions/docs/SOURCE_POLICY.md`
- `codex/src/fluxemu/carbon_transitions/docs/UNRESOLVED_MAPPINGS.md`
- `codex/examples/ecoli_core/ATOM_MAPS.md`
- `codex/examples/ecoli_core/ISOTOPE_SUBNETWORK.md`
- `codex/examples/ecoli_core/build_isotope_model.py`
- frozen Stage A2 `theta0_flux_summary.csv`, `theta1_flux_summary.csv`, and
  both 100-row complete flux-state libraries.

The two E. coli mfapy files contain the same explicit reaction-transition
catalogue.  The carbon-transition library is useful where its provenance
points back to an explicit checked mfapy map.  The older local E. coli-core
example is not sufficient authority by itself: it was built as a smaller
forward example, excludes PPP, glyoxylate, glutamate cycling and the relevant
succinate transport, and some of its local conventions differ from the direct
mfapy E. coli convention.  In particular, its simple citrate construction
must not replace the explicit E. coli source transition
`AB + CDEF -> FEDBAC`, and its prior reaction selection cannot establish R1
ancestry completeness.

## Class-restricted structural directions

The exact FVA extrema below were read from the frozen Stage A2 class summary
artifacts.  A negative range means the reverse of the canonical COBRA reaction
is potentially used.

| COBRA reaction | Theta 0 range | Theta 1 range | ancestry consequence |
|---|---:|---:|---|
| `GLCpts` | `[10, 10]` | `[10, 10]` | forward required |
| `PGI` | `[-3.03363607643, 9.82442916925]` | `[9.17067031149, 9.89250765464]` | both directions required in union |
| `FBA` | `[4.86207432292, 9.14809607148]` | `[9.23781371849, 9.47842616621]` | forward required |
| `RPI` | `[-4.90163303219, -0.615611283625]` | `[-0.617517315241, -0.376904867525]` | reverse required |
| `RPE` | `[-0.620909006872, 7.9564322135]` | `[-0.388284426523, 0.104320027906]` | both required |
| `TKT1` | `[-0.15453620107, 4.13280408212]` | `[-0.0966389592444, 0.146805713158]` | both required |
| `TALA` | `[-0.15453620107, 4.13280408212]` | `[-0.0966389592444, 0.146805713158]` | both required |
| `TKT2` | `[-0.466372805801, 3.82362813138]` | `[-0.291645467278, -0.0424856852513]` | both required in union |
| `PPC` | `[0, 6.51236512322]` | `[1.26197323451, 18.1079533036]` | forward required |
| `PPCK` | `[0, 3.4322]` | `[0, 13.7022221176]` | forward required |
| `FUM` | `[2.69732814825, 6.98334989681]` | `[-0.240612447716, 0.240612447716]` | both required |
| `MDH` | `[2.63781646039, 9.62408062699]` | `[-11.6710662796, 0.481224895432]` | both required |
| `GLUDy` | `[-4.70525735163, -1.01882031459]` | `[-2.84542070218, 10.9771076393]` | both required; forward Glu-to-aKG occurs in Theta 1 |
| `GLUSy` | `[0, 3.4322]` | `[0, 13.7022221176]` | forward required; two sourced components at one physical flux |
| `BIOMASS_Ecoli_core_w_GAM` | `[0.856443076829, 0.873921506968]` | `[0.524352904181, 0.54018423278]` | strictly active aKG-producing gap |
| `SUCCt2_2` | `[0, 4.57626666667]` | `[0, 18.2696294901]` | forward succinate-producing gap |

The gaps are not hypothetical corners missed by sampling:

- `GLUSy` is positive in all 200 frozen ACHR rows.  Ten Theta 1 rows also
  have positive `GLUDy`, so its two-component mapping is operationally
  required rather than optional.
- `BIOMASS_Ecoli_core_w_GAM` is positive in every row and at every feasible
  class point by the frozen viability floor.
- `SUCCt2_2` is positive in all 200 frozen rows.
- `ME1`, `ME2`, and `AKGDH` are positive in all 200 rows, so the TCA gaps can
  propagate to the pyruvate/Ala ancestry as well as OAA/Asp, aKG/Glu,
  succinate, and malate.

## Target reporter roots

| target | isotope root in COBRA network | observation transition | checked source | status before upstream closure |
|---|---|---|---|---|
| Ala `1:2:3` | `pyr_c` | `Pyr ABC -> Ala ABC` | Example 2/Tutorial r58 | explicit observational identity |
| Asp `1:2:3:4` | `oaa_c` (`Oxa`) | `Oxa ABCD -> Asp ABCD` | Example 2/Tutorial r59 | explicit observational identity |
| Glu `1:2:3:4:5` | `akg_c` (`aKG`) | `aKG ABCDE -> Glu ABCDE` | Example 2/Tutorial r61 | explicit observational identity |
| R5P `1:2:3:4:5` | `r5p_c` | direct full-pool observation | checked five-carbon metabolite definition | explicit positions |
| S7P `1:2:3:4:5:6:7` | `s7p_c` | direct full-pool observation | checked seven-carbon metabolite definition | explicit positions |
| Succinate `1:2:3:4` | `succ_c` | direct full-pool observation | checked four-carbon symmetric metabolite definition | explicit positions; ancestry blocked |
| Malate `1:2:3:4` | `mal__L_c` | direct full-pool observation | checked four-carbon L-malate definition | explicit positions; ancestry blocked |

The observational Glu reporter must remain distinct in the implementation
from the physical COBRA metabolite `glu__L_c`.  The former is an identity
readout of `akg_c`; the latter participates in `GLNS`, `GLUN`, `GLUSy`,
`GLUDy`, transport, and biomass balances.  Conflating them would hide the
the biomass mapping gap and the source-backed GLUSy decomposition.

Reporter transitions do not carry a physical COBRA flux, do not change the
95-reaction state, and must not be added as pseudo-reactions to the LP.

## Target-specific direct producers

### Ala full carbon

The observation root is `pyr_c`.  Potential mapped producers are:

- `GLCpts:forward`, PEP skeleton component: `PEP ABC -> Pyr ABC`;
- `PYK:forward`: `PEP ABC -> Pyr ABC`;
- `ME1:forward` and `ME2:forward`: `Mal ABCD -> Pyr ABC + CO2 D`.

The recursive union reaches glycolysis, PPP, PEP/OAA cycling, TCA,
glyoxylate bypass, physical glutamate/aKG cycling, and biomass-returned aKG.
It is therefore blocked by `BIOMASS_Ecoli_core_w_GAM`.  The
malic-enzyme route is positive in all frozen rows, so this is not merely an
unused theoretical branch.

### Asp full carbon

The observation root is `oaa_c`.  Potential mapped producers are:

- `PPC:forward`: `PEP ABC + CO2 D -> Oxa ABCD`;
- `MDH:forward`: `Mal ABCD -> Oxa ABCD`.

`MDH` also requires its explicit reverse `Oxa -> Mal` in the class union.
The recursive closure reaches the same TCA, glutamate/aKG, and biomass gap as
Ala.  Status: blocked.

### Glu full carbon

The observation root is `akg_c`.  Potential physical producers are:

- lumped citrate/isocitrate entry followed by `ICDHyr:forward`;
- `GLUDy:forward`, explicitly possible in Theta 1;
- `BIOMASS_Ecoli_core_w_GAM:forward`, whose COBRA stoichiometry produces
  `4.1182 akg_c` per unit biomass flux.

The reporter transition `aKG ABCDE -> Glu ABCDE` is explicit, but it cannot
repair missing physical production into `akg_c`.  The physical GLUSy branch
is covered separately by the two checked component maps.  Status: blocked
directly by biomass.

### R5P full carbon

Direct production directions are:

- `RPI:reverse`: source r29 `Ru5P ABCDE -> R5P ABCDE`;
- `TKT1:reverse`: source r34
  `GAP HIJ + S7P FGABCDE -> Xu5P FGHIJ + R5P ABCDE`.

Recursive closure contains oxidative and non-oxidative PPP, upper glycolysis,
and glucose entry.  All required forward and reverse transitions in this
closure are explicit in the checked E. coli mapping source.  It does not need
the downstream TCA/nitrogen branches to determine carbon origins.  Status:
structurally source-complete on its own.

### S7P full carbon

Direct production directions are:

- `TKT1:forward`: source r33
  `R5P ABCDE + Xu5P FGHIJ -> S7P FGABCDE + GAP HIJ`;
- `TALA:reverse`: source r36
  `E4P GHIJ + F6P DEFABC -> S7P DEFGHIJ + GAP ABC`.

Its recursive closure is the same PPP/upper-glycolysis/glucose-entry system as
R5P, with explicit maps for both directions of RPE, TKT1, TALA and TKT2 and
the required reverse direction of RPI.  Status: structurally source-complete
on its own.

### Succinate full carbon

Potential physical producers are:

- the exact `AKGDH:forward` + `SUCOAS:reverse` lump, source r19
  `aKG ABCDE -> Suc BCDE + CO2 A`;
- the exact `ICL:forward` + `MALS:forward` glyoxylate lump, source r26
  `IsoCit ABCDEF + AcCOA GH -> Mal ABHG + Suc FCDE`;
- `FRD7:forward`, source r21 `Fum ABCD -> Suc ABCD`;
- `SUCCt2_2:forward`, `succ_e -> succ_c`, for which no authoritative checked
  atom transition was found.

The last reaction is active in all frozen sampled states.  It participates in
an extracellular recycling relation rather than approved net organic uptake:
the complete states satisfy
`v_SUCCt3 = v_SUCCt2_2 + v_EX_succ_e` within numerical precision.  This does
not authorize silently deleting the gross transport cycle, and it does not
create an atom map.  Status: blocked directly by `SUCCt2_2`, and recursively
by the aKG/biomass gap.

### Malate full carbon

Potential physical producers are:

- `FUM:forward`: source r22 `Fum ABCD -> Mal ABCD`;
- `MDH:reverse`: source r25 `Oxa ABCD -> Mal ABCD`;
- the `ICL` + `MALS` lump, source r26, malate component `ABHG`.

Both directions of FUM and MDH are potentially used over the class union and
both directions are explicit in the checked E. coli source.  Recursive TCA
closure reaches biomass-produced aKG, physical Glu/GLUSy, and the succinate
transport branch.  Status: blocked.

## Required upstream mapped modules

Subject to resolving the two gaps, the structural target union needs these
source-backed modules.  This is a reaction-ancestry list, not an EMU graph.

### Glucose entry and glycolysis

- `GLCpts:forward`, decomposed into two atom-transfer components at the same
  physical flux: source r1 `SubsGlc ABCDEF -> G6P ABCDEF` and source r14
  `PEP ABC -> Pyr ABC`.
- `PGI:forward` r2 and `PGI:reverse` r3.
- `PFK:forward` r4 and `FBP:forward` r5.
- `FBA:forward` r6 and `TPI:forward` r8.
- exact `GAPD:forward` + `PGK:reverse` intermediate lump using source r10
  `GAP ABC -> PGA ABC`.
- exact `PGM:reverse` + `ENO:forward` intermediate lump using source r12
  `PGA ABC -> PEP ABC`.
- `PYK:forward` r14 and `PPS:forward` r15 skeleton transition.
- `PDH:forward` r16 and `PFL:forward` r51.

The PTS decomposition accounts for all nine carbon atoms: six glucose atoms
enter G6P, and all three PEP atoms enter pyruvate.  Both components receive
exactly `v_GLCpts`; neither is an independently fitted or sampled flux.  This
special audit passes at the structural-map level.

### Pentose-phosphate pathway

- exact `G6PDH2r:forward` + `PGL:forward` lump to 6PG using r27;
- `GND:forward` r28;
- `RPI:reverse` r29 (the only RPI direction feasible in the frozen union);
- `RPE:forward` r31 and reverse r32;
- `TKT1:forward` r33 and reverse r34;
- `TALA:forward` r35 and reverse r36;
- `TKT2:forward` r37 and reverse r38.

### TCA, glyoxylate, and anaplerosis

- `PPC:forward` r40 and `PPCK:forward` r41;
- `ME1:forward` / `ME2:forward` r42;
- exact `CS` + `ACONTa` + `ACONTb` lump using r17
  `AcCOA AB + Oxa CDEF -> IsoCit FEDBAC`;
- `ICDHyr:forward` r18;
- exact `AKGDH:forward` + `SUCOAS:reverse` lump using r19;
- `SUCDi:forward` r20 and `FRD7:forward` r21;
- `FUM:forward` r22 and reverse r23;
- `MDH:forward` r24 and reverse r25;
- exact `ICL:forward` + `MALS:forward` lump using r26.

### Five-carbon nitrogen network

- `GLUDy:forward` and reverse: Example 3 r49/r50 explicit identity maps;
- `GLUN:forward` Gln-to-Glu and `GLNS:forward` Glu-to-Gln: explicit
  five-carbon skeleton maps occur in checked mfapy examples;
- `GLUSy:forward`: decomposed into checked `aKG -> Glu` and `Gln -> Glu`
  components, each at `v_GLUSy`; no branch weight and no independently chosen
  flux is introduced;
- `BIOMASS_Ecoli_core_w_GAM:forward` aKG product: **missing** explicit source
  mapping.

## Auditable lumping equalities

The following candidates are structurally justified by a single unbranched
COBRA intermediate balance.  The frozen samples confirm the equalities to
approximately `1e-13` or better:

| projection | required COBRA equality | reason |
|---|---|---|
| GAP to 3PG | `v_GAPD = -v_PGK` | `13dpg_c` occurs only in those two reactions |
| 3PG to PEP | `-v_PGM = v_ENO` | `2pg_c` occurs only in those two reactions |
| G6P to 6PG | `v_G6PDH2r = v_PGL` | `6pgl_c` occurs only in those two reactions |
| AcCoA + OAA to IsoCit | `v_CS = v_ACONTa = v_ACONTb` | citrate and aconitate are unbranched before isocitrate |
| aKG to succinate | `v_AKGDH = -v_SUCOAS` | succinyl-CoA is unbranched |
| glyoxylate bypass | `v_ICL = v_MALS` | glyoxylate occurs only in ICL and MALS |

These equalities justify using the checked net isotope transition without
claiming that the physical reactions are one reaction.  No equality is
assumed merely from pathway adjacency.

## Carbon-source termination

- `glc__D_e` is the only terminal organic carbon source in the ancestry and
  is fixed at the Stage A2 uptake magnitude of 10.
- `CO2t` has a strictly negative canonical range in both classes
  (`[-23.553636644, -21.2655033107]` and
  `[-14.1058801099, -4.97106536489]`), so carbon dioxide is exported, not
  imported.  Internal CO2 used by PPC is generated by mapped
  decarboxylations; external CO2 is not an entering ancestry source here.
- `succ_e` is an internal/export recycling intermediate because alternative
  organic uptake is disabled; it is not a terminal exogenous source.
- No other organic exchange can enter the frozen classes.

Thus no unapproved organic carbon source was found entering target ancestry.
The succinate transport gap remains a mapping/representation problem even
though it is not net external carbon uptake.

## Exact STOP conditions

### 1. Biomass aKG production

The physical reaction is strictly active and includes
`+4.1182 akg_c`.  Its aKG production ranges are:

- Theta 0: `3.527003878997` to `3.598983549996`;
- Theta 1: `2.159390129998` to `2.224586707435`.

The checked isotope models mark biomass drains as `nd` and do not map the
COBRA aggregate biomass reaction.  Treating the whole reaction as a
turnover-only sink would silently discard a significant production flux into
a retained target-ancestry pool.  Assigning that product to glutamate,
glutamine, or any other precursor would invent chemistry.  This gap blocks
Glu directly and the TCA-linked targets recursively.

### 2. SUCCt2_2 compartment transfer

`SUCCt2_2:forward` produces the retained `succ_c` target pool from `succ_e`.
No explicit checked succinate compartment-transition map was found.  A generic
identity transport map for a different metabolite cannot establish the
succinate mapping.  Dropping the gross `SUCCt2_2`/`SUCCt3` cycle would violate
the frozen complete-state projection requirement.  This gap is operational:
both transport directions are positive in all frozen rows.

## Per-target completeness result

| target | local reporter/direct-pool mapping | recursive production coverage | result |
|---|---|---|---|
| Ala full | PASS | biomass aKG gap reachable through TCA/malic enzyme | BLOCKED |
| Asp full | PASS | biomass aKG gap reachable through TCA/MDH | BLOCKED |
| Glu full | PASS | biomass produces its aKG root without a map | BLOCKED |
| R5P full | PASS | checked PPP/upper-glycolysis/glucose maps cover closure | PASS in isolation |
| S7P full | PASS | checked PPP/upper-glycolysis/glucose maps cover closure | PASS in isolation |
| Succinate full | PASS | SUCCt2_2 direct gap plus aKG/biomass gap | BLOCKED |
| Malate full | PASS | aKG/biomass and succinate-cycle gaps reachable | BLOCKED |

Because Stage B requires zero unexplained mapped-production gaps over all
seven targets and all potentially active class directions, the overall result
cannot be promoted to complete.

## No-isotope execution audit

- No tracer was instantiated.
- No source MID or target MID was formed.
- No EMU graph was compiled or numerically evaluated.
- No stationary isotope equation was solved.
- No mfapy Python module or `calmdv` function was imported or called.
- No forward simulation, measurement noise, hypothesis test, inverse MFA,
  topology inference, robust estimation, or measurement design was run.
- No Stage A2 flux state was regenerated or modified.
