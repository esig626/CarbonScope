# Agent C proposal: flux projection and mapping-coverage gate

Status: **PROPOSAL ONLY — STOP GATE TRIGGERED BEFORE PROJECTION**

This audit used only the checked COBRA model, the frozen Stage A2 flux
artifacts, and repository-resident atom-transition text.  It did not import or
execute mfapy, instantiate a tracer, compile or evaluate an EMU graph,
calculate a MID, resample a flux class, or run any statistical inference.

## Frozen-class reconstruction and independent FVA

The common model was independently reconstructed from
`vendor/cobrapy/tests/data/e_coli_core.xml` with the Stage A2 flux-only
utilities.  Its viable feasible-set fingerprint is
`d61a2ed972bc452df331fe50091ffec361f45cebfe264e0c3faa6d4a9459e3f3`.
The reconstructed frozen values were:

- `mu_max = 0.8739215069684749`;
- common biomass floor `0.5243529041810849` (`eta = 0.60`);
- `J0* = 0.8739215069684307`, threshold `0.8564430768290621`;
- `J1* = 12.030622385803783`, threshold `11.790009938087707`.

COBRApy FVA was rerun separately on both class-constrained models for all 95
reactions.  Both 95-row results were finite.  Compared with the frozen Stage
A2 exact-FVA columns, the maximum absolute discrepancies were
`7.105427357601002e-15` for Theta 0 and `3.552713678800501e-15` for Theta 1.
Thus the independently reconstructed directional-coverage ranges reproduce
the frozen classes without changing or resampling them.

Using `1e-9` native-flux units as the proposal-only activity tolerance, the
candidate mapped-production closure contains 41 canonical-forward directions
and 12 canonical-reverse directions over 45 physical COBRA reactions.  The
reverse directions are `PGI`, `PGK`, `PGM`, `SUCOAS`, `FUM`, `MDH`, `RPI`,
`RPE`, `TKT1`, `TALA`, `TKT2`, and `GLUDy`.  Explicit checked maps cover all 12
reverse directions; no reverse transition was created by reversing a string.

The proposed R1 directional lift remains

```text
v_forward = max(v, 0)
v_reverse = max(-v, 0)
```

outside the `1e-9` zero band, with both components zero inside it.  It is a
net-flux lift and adds no gross exchange flux to a signed COBRA reaction.

## LP proof of candidate lumping equalities

Each equality was independently minimized and maximized on each complete
class polytope, rather than inferred from sampled rows.  All optimizations
were optimal.  The largest absolute endpoint over the following equalities
was `3.552713678800501e-15`:

| source-backed net transition | exact COBRA equality |
|---|---|
| GAP to 3PG | `v_GAPD + v_PGK = 0` |
| 3PG to PEP | `v_PGM + v_ENO = 0` |
| G6P to 6PG | `v_G6PDH2r - v_PGL = 0` |
| acetyl-CoA + OAA to isocitrate | `v_CS - v_ACONTa = 0`; `v_ACONTa - v_ACONTb = 0` |
| aKG to succinate | `v_AKGDH + v_SUCOAS = 0` |
| glyoxylate bypass | `v_ICL - v_MALS = 0` |
| acetate sink | `v_PTAr + v_ACKr = 0` |

The 200 frozen ACHR rows independently satisfy these relationships with a
worst absolute residual of `4.760636329592671e-13`.  These results justify the
listed net mappings over both frozen classes.  They do not validate atom maps
for any suppressed intermediate.

## GLUSy reconciliation

I accept a two-component projection for `GLUSy:forward` under the task's
explicit rule allowing one physical reaction to drive several mapped carbon
skeleton components:

```text
aKG ABCDE -> Glu ABCDE      at w = v_GLUSy
Gln ABCDE -> Glu ABCDE      at w = v_GLUSy
```

The two exact component transitions occur in checked vendor sources:
`Example_3_MCF7_model.txt` r47 and r50 (and are repeated in Example 7).  Both
components use the same physical COBRA flux, account for all ten substrate
and ten product carbons, and introduce neither a branch weight nor an
independent flux.  This is also consistent with the checked transition
library's existing practice of constructing multi-skeleton transaminase maps
as curated composites from independently explicit skeleton transfers.  The
GLUSy proposal therefore does not infer an atom permutation from COBRA
stoichiometry.

This reasoning cannot be transferred to the biomass pseudo-reaction.  Its
many carbon precursors do not provide an authoritative correspondence to its
aKG product, so choosing glutamate (or another precursor) as that product's
origin would invent chemistry.

Agent B subsequently confirmed this conditional GLUSy decomposition from the
same direct source lines and independently agreed that it creates neither a
new atom permutation nor an independent flux.

## Mapping stop gates

### Biomass production of aKG

`BIOMASS_Ecoli_core_w_GAM:forward` is strictly positive throughout both
classes and produces `4.1182 akg_c` per unit flux.  Class FVA therefore makes
the unmapped aKG production unavoidable:

- Theta 0: `3.5270038789974434 .. 3.5989835499973895`;
- Theta 1: `2.1593901299985445 .. 2.2245867074360777`.

No checked repository map identifies the carbon origin of this pseudo-product.
The reaction cannot be treated only as a sink while silently dropping aKG
production into the retained Glu/TCA ancestry.  This is an independent hard
stop.

### Gross succinate transport subsystem

`SUCCt2_2:forward` has FVA ranges `0 .. 4.5762666666676175` in Theta 0 and
`0 .. 18.269629490106887` in Theta 1.  It is positive in all 200 frozen ACHR
rows, yet no checked source provides `succ_e -> succ_c` atom positions.

The full recursive closure also prevents `SUCCt3:forward` from being treated
as a terminal turnover-only sink.  Its `succ_e` product is consumed by
`SUCCt2_2` back into the requested intracellular succinate pool.  Both class
polytopes satisfy exactly

```text
v_SUCCt3 - v_SUCCt2_2 - v_EX_succ_e = 0.
```

Both transporters are positive in every frozen sampled row.  Example 2 r53
contains only `Suc -> Succinateex` with `nd`, not an atom transition.  Thus
the gross subsystem lacks explicit maps for both `succ_c -> succ_e` and
`succ_e -> succ_c`.  Cancelling it to net secretion would drop frozen physical
flux and contradict the mandated complete-state projection and net-flux lift.
`EX_succ_e` is the turnover-only terminal drain once `succ_e` is retained.

Agent B independently reached the same recursive-pool conclusion: r53's
`nd/nd` record maps neither physical transport direction.

Consequently the mapped-production closure has 53 required physical
directions (41 forward, 12 reverse): 50 are source-covered and three are
missing (`BIOMASS_Ecoli_core_w_GAM:forward`, `SUCCt3:forward`, and
`SUCCt2_2:forward`).  After source-backed lumping/decomposition these become
48 isotope directional components: 45 mapped and three missing.

## Candidate reaction categories

Because the return transporter makes extracellular succinate an ancestry
intermediate rather than a terminal sink, the proposal partitions all 95
COBRA reactions as follows:

- Category A, mapped production or unresolved required production: 45;
- Category B, turnover-only consumption: 9;
- Category C, isotope-irrelevant for the seven-target closure: 41.

The full lists and rationales are in `agent_c_flux_geometry_audit.json`.
Category A includes the three missing directions above.  Category B does not
receive invented product maps.  The glucose boundary exchange is documented
in Category C as boundary bookkeeping because the exact source entry flux and
both PTS carbon skeletons are represented by the mapped `GLCpts` projection;
it is not silently interpreted as an atom transition.

## Frozen-state manifest audit

The two ACHR files contain 100 states each in the identical checked 95-reaction
order.  The exact biomass and acetate LP solutions are additional complete
states.  Stage A2 also contains two pFBA columns, but each is numerically the
same as its corresponding LP solution (`1.4566126083082054e-13` and
`2.3092638912203256e-14` maximum coordinate difference).  To obey the rule
against duplicating numerically identical states, the proposed manifest has
202 unique numerical vectors and records the two pFBA provenances as aliases
of the corresponding LP representatives rather than duplicating their rows.

The compact-JSON SHA-256 of the reaction-order list is
`b749709b082fb75772d8f9f43d7959871658a95217927bd670ff935185bddc76`.
Input artifact SHA-256 values are recorded in the JSON audit.  No Stage A2
artifact was changed.

## Deliberately unexecuted work

The mapping-completeness gate failed before the dry-run projection.  Therefore
no frozen state was projected, no directional projected-state table was
created, and no projected isotope-pool balance audit was run.  Reporting a
projection or balance result in the presence of these production gaps would
misrepresent missing chemistry as zero or as a sink.

Agent C's proposal verdict is **BLOCKED**.
